//import logo from './logo.svg';
import './App.css';
import InputTypeFormGenerator from './components/new/InputTypeFormGenerator';
//import AddInputs from './components/AddInputs';
//import UserForm from './components/UserForm';

function App() {
  return (
    <div className="App">
      {/* <AddInputs/>
    <UserForm/> */}
    <InputTypeFormGenerator/>
    </div>
  );
}

export default App;
